# Contenu du Sprint0

- Rédaction des besoins fonctionnels et non-fonctionnels (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-developpement/-/blob/main/Besoins.md)
- Rédaction des Issues (User Story) associées (Backlog, (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-developpement/-/blob/main/README.md ou https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-developpement/-/blob/main/Issues.md)
- Rédactions des scénarios de test en Gherkin (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-developpement/-/blob/main/ScenariosTest.md))
- Rédaction des Tasks associées (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-developpement/-/blob/main/Tasks.md)
- Maquette de notre application web (Figma)
- Mini prototype ?