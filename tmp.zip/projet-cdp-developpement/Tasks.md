# Ordre des Tâches avec Dépendances

---

## 1. Gestion de la Connexion

### Étape 1: Création des Pages HTML
1. **ID**: `GCP001` - **Créer une page d'accueil avec possibilité de connexion ou d'inscription.**
2. **ID**: `GCP002` - **Créer une page de connexion avec un champ "nomutilisateur" et un champ "motdepasse".**
3. **ID**: `GCP003` - **Créer une page d'inscription avec un champ "nomutilisateur" et un champ "motdepasse".**
4. **ID**: `GCP004` - **Faire le lien entre ces trois pages (navigation et redirections).**
- **Responsable**: _Quentin_
- **Estimation (heures)**: _(Temps estimé à remplir)_
   - **Dépendances**: `GCP001`, `GCP002`, `GCP003` doivent être terminées.

### Étape 2: Enregistrement d'un Compte
5. **ID**: `EAC001` - **Développer des classes JS permettant l'enregistrement d'un compte en local.**
6. **ID**: `EAC002` - **Développer des classes JS permettant l'ajout de projets à un compte spécifique.**
7. **ID**: `EAC003` - **Enregistrer en local un nouveau compte.**
- **Responsable**: _Quentin_
- **Estimation (heures)**: _(Temps estimé à remplir)_
   - **Dépendances**: `EAC001` doit être terminée.

### Étape 3: Connexion et Déconnexion
8. **ID**: `CAC001` - **Rendre l'accès à un compte déjà créé possible avec les bonnes informations de connexion.**
   - **Dépendances**: `EAC003` doit être terminée.
9. **ID**: `CAC002` - **Rediriger vers l'accueil utilisateur après la connexion.**
   - **Dépendances**: `CAC001` doit être terminée.
10. **ID**: `DAC001` - **Rendre la déconnexion d'un compte possible.**
    - **Dépendances**: `CAC002` doit être terminée.
11. **ID**: `DAC002` - **Rediriger vers la page d'accueil après la déconnexion.**
    - **Dépendances**: `DAC001` doit être terminée.
- **Responsable**: _Quentin_
- **Estimation (heures)**: _(Temps estimé à remplir)_
---

## 2. Gestion des Tâches

### Étape 1: Création de la Structure de Tâches
12. **ID**: `CT001` - **Créer une classe `Task` qui représente une tâche avec un titre et une description.**
13. **ID**: `CT002` - **Créer une classe `TaskBDD` pour gérer une liste de tâches.**
    - **Dépendances**: `CT001` doit être terminée.
14. **ID**: `CT003` - **Ajouter une méthode `addTask(title, description)` dans `TaskBDD`.**
    - **Dépendances**: `CT002` doit être terminée.
15. **ID**: `CT004` - **Vérifier que le titre et la description ne sont pas vides avant l'ajout.**
    - **Dépendances**: `CT003` doit être terminée.
16. **ID**: `CT005` - **Ajouter la tâche à la liste et enregistrer un log de confirmation.**
    - **Dépendances**: `CT004` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 2: Gestion des Tâches Complètes et Suppression
17. **ID**: `LT001` - **Implémenter `getAllTasks()` pour renvoyer la liste complète des tâches.**
    - **Dépendances**: `CT005` doit être terminée.
18. **ID**: `LT002` - **Afficher la liste des tâches dans la console de manière organisée.**
    - **Dépendances**: `LT001` doit être terminée.
19. **ID**: `MTC001` - **Ajouter une méthode `updateTaskStatus(taskId, status)` pour changer le statut de la tâche.**
    - **Dépendances**: `LT002` doit être terminée.
20. **ID**: `MTC002` - **Définir des statuts valides pour les tâches.**
    - **Dépendances**: `MTC001` doit être terminée.
21. **ID**: `ST001` - **Créer `removeTask(taskId)` pour supprimer une tâche de `TaskBDD`.**
    - **Dépendances**: `MTC002` doit être terminée.
22. **ID**: `ST002` - **Vérifier l'existence de la tâche avant de la supprimer.**
    - **Dépendances**: `ST001` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 3: Gestion Avancée des Tâches
23. **ID**: `AT001` - **Ajouter `assignTaskToDeveloper(taskId, developerName)` pour assigner une tâche à un développeur.**
    - **Dépendances**: `ST002` doit être terminée.
24. **ID**: `ATI001` - **Créer `linkTaskToIssue(taskId, issueId)` pour associer une tâche à une issue.**
    - **Dépendances**: `AT001` doit être terminée.
25. **ID**: `FT001` - **Implémenter `filterTasksByStatus(status)` pour filtrer les tâches par statut.**
    - **Dépendances**: `ATI001` doit être terminée.
26. **ID**: `DT001` - **Ajouter `setTaskDependency(taskId, dependentTaskId)` pour définir les dépendances.**
    - **Dépendances**: `FT001` doit être terminée.
27. **ID**: `DFT001` - **Ajouter `setTaskDeadline(taskId, deadline)` pour définir une date de fin.**
    - **Dépendances**: `DT001` doit être terminée.
28. **ID**: `EDT001` - **Ajouter `setTaskDurationEstimate(taskId, duration)` pour estimer la durée d'une tâche.**
    - **Dépendances**: `DFT001` doit être terminée.
29. **ID**: `CTC001` - **Implémenter `addCommentToTask(taskId, comment)` pour ajouter des commentaires.**
    - **Dépendances**: `EDT001` doit être terminée.
30. **ID**: `HT001` - **Ajouter `getTaskHistory(taskId)` pour voir l'historique des statuts.**
    - **Dépendances**: `CTC001` doit être terminée.
31. **ID**: `MT001` - **Créer `editTask(taskId, newTitle, newDescription)` pour modifier le contenu d'une tâche.**
    - **Dépendances**: `HT001` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

---

## 3. Gestion des Issues

### Étape 1: Création et Gestion Initiale
32. **ID**: `CI001` - **Créer une classe `Issue` avec une description et une classe `IssuesBDD`.**
33. **ID**: `LI001` - **Implémenter `getAllIssues()` pour obtenir la liste complète des issues.**
    - **Dépendances**: `CI001` doit être terminée.
34. **ID**: `SI001` - **Ajouter `updateIssueStatus(issueId, status)` pour gérer le statut des issues.**
    - **Dépendances**: `LI001` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 2: Gestion Avancée des Issues
35. **ID**: `AIR001` - **Créer `linkIssueToRelease(issueId, releaseId)` pour lier une issue à une release.**
    - **Dépendances**: `SI001` doit être terminée.
36. **ID**: `SI002` - **Implémenter `removeIssue(issueId)` pour supprimer une issue.**
    - **Dépendances**: `AIR001` doit être terminée.
37. **ID**: `FI001` - **Ajouter `filterIssuesByStatus(status)` pour filtrer les issues.**
    - **Dépendances**: `SI002` doit être terminée.
38. **ID**: `MI001` - **Créer `editIssue(issueId, newDescription)` pour modifier une issue.**
    - **Dépendances**: `FI001` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

---

## 4. Gestion des Releases

### Étape 1: Création et Liste des Releases
39. **ID**: `CR001` - **Créer une classe `Release` et `ReleasesBDD` pour gérer les releases.**
40. **ID**: `LR001` - **Implémenter `getAllReleases()` pour retourner toutes les releases.**
    - **Dépendances**: `CR001` doit être terminée.
41. **ID**: `SR001` - **Ajouter `updateReleaseStatus(releaseId, status)` pour changer le statut.**
    - **Dépendances**: `LR001` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 2: Gestion et Filtrage
42. **ID**: `FR001` - **Créer `filterReleasesBystatus(status)` pour filtrer les releases par statut.**
    - **Dépendances**: `SR001` doit être terminée.
43. **ID**: `DR001` - **Créer `getReleaseDetails(releaseId)` pour obtenir les détails d'une release.**
    - **Dépendances**: `FR001` doit être terminée.
44. **ID**: `RR001` - **Implémenter `removeRelease(releaseId)` pour supprimer une release.**
    - **Dépendances**: `DR001` doit être terminée.
45. **ID**: `ER001` - **Ajouter `editRelease(releaseId, newTitle, newDescription, newDate)` pour modifier une release.**
    - **Dépendances**: `RR001` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

---

## 5. Gestion des Documentations

### Étape 1: Création et Liste des Documentations
46. **ID**: `CD001` - **Créer une classe `Documentation` et `DocumentationsBDD` pour gérer les documentations.**
47. **ID**: `LD001` - **Implémenter `getAllDocumentations()` pour retourner toutes les documentations.**
    - **Dépendances**: `CD001` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 2: Association et Suppression
48. **ID**: `ADR001` - **Créer `linkDocumentationToRelease(documentationId, releaseId)` pour lier une documentation à une release.**
    - **Dépendances**: `LD001` doit être terminée.
49. **ID**: `SD001` - **Implémenter `removeDocumentation(documentationId)` pour supprimer une documentation.**
    - **Dépendances**: `ADR001` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 3: Modification
50. **ID**: `MD001` - **Ajouter `editDocumentation(documentationId, newTitle, newValidityDate, newContent)` pour modifier une documentation.**
    - **Dépendances**: `SD001` doit être terminée.
- **Responsable**: _Tarik_
- **Estimation (heures)**: _(Temps estimé à remplir)_

---

## 6. Mise en Place des Routes et Gestion Middleware

### Étape 1: Correction et Ajout des Routes
46. **ID**: `BRG001` - **Correction des routes suivantes pour s'assurer de leur bon fonctionnement : `/user`, `/create_project`, `/projects`, `/edit_project`.**
- **Responsable**: _Quentin_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

47. **ID**: `BRG002` - **Ajout des routes suivantes : `/user/logout`, `/help`, `/allTasks`, `/creds`.**
- **Responsable**: _Quentin_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 2: Gestion des Middleware
48. **ID**: `BRG003` - **Mise en place d'un middleware interdisant l'accès au site si aucune authentification n'a été faite au préalable.**
- **Responsable**: _Quentin_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

---

## 7. Gestion Esthétique et Optimisation

### Étape 1: Améliorations Esthétiques
49. **ID**: `ES001` - **Gestion de l'esthétique générale du site pour améliorer l'expérience utilisateur.**
- **Responsable**: _Quentin_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 2: Intégration Dynamique
50. **ID**: `TH001` - **Changement des fichiers HTML en fichiers EJS pour intégrer des variables dynamiques comme `projects`.**
- **Responsable**: _Quentin_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 3: Création des Vues
51. **ID**: `SS001` - **Création des views logout.ejs, help.ejs, allTasks.ejs et creds.ejs associées aux nouvelles routes.**
    - **Dépendances**: `BRG002` doit être terminée.
- **Responsable**: _Quentin_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

---

## 8. Setup Application

### Étape 1: Gestion des Dépendances
52. **ID**: `DG001` - **Création d'un fichier bash `setup.sh` qui télécharge l'ensemble des dépendances nécessaires à l'exécution de l'application.**
- **Responsable**: _Quentin_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

---

## 9. Tests

### Étape 1: Tests des Routes et Statut HTTP
53. **ID**: `SHT001` - **Mise en place de tests pour les routes avec vérification des `HTTP Status Codes`.**
- **Responsable**: _Juliette_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

---

## 10. Liaison Backend et Frontend

### Étape 1: Fonctionnalité Releases
54. **ID**: `LBF001` - **Faire fonctionner la gestion des `Releases` côté frontend en consommant les routes backend associées.**
- **Responsable**: _(Nom de la personne à remplir)_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 2: Fonctionnalité Documentations
55. **ID**: `LBF002` - **Faire fonctionner la gestion des `Documentations` côté frontend en intégrant les données reçues du backend.**
- **Responsable**: _(Nom de la personne à remplir)_  
- **Estimation (heures)**: _(Temps estimé à remplir)_

### Étape 3: Fonctionnalité Issues
56. **ID**: `LBF003` - **Faire fonctionner la gestion des `Issues` côté frontend en liant les actions utilisateurs aux routes backend pertinentes.**
- **Responsable**: _(Nom de la personne à remplir)_  
- **Estimation (heures)**: _(Temps estimé à remplir)_
