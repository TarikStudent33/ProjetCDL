# Liste des Tâches effectuées durant le sprint 2

## 1. Gestion des Issues

### Création et Gestion Initiale
- **ID: IGC001** - Création de la classe `Issue` avec des attributs de description et de statut.  
- **ID: IGC002** - Implémentation de la méthode `getAllIssues()` pour obtenir la liste complète des issues.  
- **ID: IGC003** - Ajout de la méthode `updateIssueStatus(issueId, status)` pour gérer les statuts des issues.  

  **Responsable**: _Tarik_

---

### Gestion Avancée des Issues
- **ID: IAG001** - Création de la méthode `linkIssueToRelease(issueId, releaseId)` pour associer une issue à une release.  
- **ID: IAG002** - Implémentation de la méthode `removeIssue(issueId)` pour supprimer une issue.  
- **ID: IAG003** - Ajout de la méthode `filterIssuesByStatus(status)` pour filtrer les issues par statut.  
- **ID: IAG004** - Création de la méthode `editIssue(issueId, newDescription)` pour modifier une issue.  

  **Responsable**: _Tarik_

---

## 2. Gestion des Releases

### Création et Liste des Releases
- **ID: RCL001** - Création des classes `Release` et `ReleasesBDD` pour gérer les releases.  
- **ID: RCL002** - Implémentation de la méthode `getAllReleases()` pour retourner toutes les releases.  
- **ID: RCL003** - Ajout de la méthode `updateReleaseStatus(releaseId, status)` pour changer le statut d'une release.  

  **Responsable**: _Tarik_

---

### Gestion et Filtrage des Releases
- **ID: RGF001** - Création de la méthode `filterReleasesByStatus(status)` pour filtrer les releases par statut.  
- **ID: RGF002** - Implémentation de la méthode `getReleaseDetails(releaseId)` pour obtenir les détails d'une release.  
- **ID: RGF003** - Création de la méthode `removeRelease(releaseId)` pour supprimer une release.  
- **ID: RGF004** - Ajout de la méthode `editRelease(releaseId, newTitle, newDescription, newDate)` pour modifier une release.  

  **Responsable**: _Tarik_

---

## 3. Gestion des Documentations

### Création et Liste des Documentations
- **ID: DCL001** - Création des classes `Documentation` et `DocumentationsBDD` pour gérer les documentations.  
- **ID: DCL002** - Implémentation de la méthode `getAllDocumentations()` pour retourner toutes les documentations.  

  **Responsable**: _Tarik_

---

### Association et Suppression des Documentations
- **ID: DAS001** - Création de la méthode `linkDocumentationToRelease(documentationId, releaseId)` pour associer une documentation à une release.  
- **ID: DAS002** - Ajout de la méthode `removeDocumentation(documentationId)` pour supprimer une documentation.  

  **Responsable**: _Tarik_

---

### Modification des Documentations
- **ID: DM001** - Ajout de la méthode `editDocumentation(documentationId, newTitle, newValidityDate, newContent)` pour modifier une documentation.  

  **Responsable**: _Tarik_

---

## 4. Mise en Place des Routes et Gestion Middleware

### Gestion des Routes Backend
- **ID: BRG001** - Correction des routes suivantes pour s'assurer de leur bon fonctionnement :
  - `/user`, `/create_project`, `/projects`, `/edit_project`.
- **ID: BRG002** - Ajout des routes suivantes :
  - `/user/logout`, `/help`, `/allTasks`, `/creds`.
- **ID: BRG003** - Mise en place d'un middleware interdisant l'accès au site si aucune authentification n'a été faite au préalable.

  **Responsable**: _Quentin_

---

## 5. Gestion Esthétique et Optimisation

### Design et Améliorations d'Interface
- **ID: ES001** - Gestion de l'esthétique générale du site pour améliorer l'expérience utilisateur.  
- **ID: TH001** - Changement des fichiers HTML en fichiers EJS pour intégrer des variables dynamiques comme `projects`.
- **ID: SS001** - Création des views logout.ejs, help.ejs, allTasks.ejs et creds.ejs associées aux nouvelles routes (**ID: BRG002**).

  **Responsable**: _Quentin_

---

## 6. Setup Application

### Gestion des dépendances
- **ID: DG001** - Création d'un fichier bash `setup.sh` qui télécharge l'ensemble des dépendances nécessaires à l'exécution de l'application. 

  **Responsable**: _Quentin_

## 7. Tests

### Tests et Statut HTTP
- **ID: SHT001** - Mise en place de tests pour les routes avec vérification des `HTTP Status Codes`.

**Responsable**: _Juliette_

---