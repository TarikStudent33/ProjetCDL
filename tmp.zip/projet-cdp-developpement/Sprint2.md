# Contenu du Sprint2

## Partie Conduite de Projet 

- Réorganisations des tâches (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Tasks.md)
- Task2.md qui documente l'ensemble des tâches réalisées au cours de ce Sprint (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Task2.md)
- Release.md qui documente la Release associée à ce Sprint (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Release.md)
- Documentation.md modifiée (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Documentation.md)

## Partie Code

- Ajout de routes (/contacts, /creds, https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/code/routes)
- Ajout de views ejs remplaçant totalement ou presque nos templates HTML (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/code/views)
- Modification de notre base de données locale ainsi que de certaines classes de notre application (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/code/merge.js)
- Visualisation des Tâches
- Implémentation d'un middleware afin de renvoyer automatiquement à la route /login si l'on n'est pas connecté (excepté / et /register)
- Route /user/logout modifiée afin d'obtenir une déconnexion agréable/esthétique (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/code/routes/user.js)
- Amélioration du côté esthétique de notre application (css, ejs)
- Ajout d'un fichier setup.sh installant toutes les dépendances nécessaires à notre application