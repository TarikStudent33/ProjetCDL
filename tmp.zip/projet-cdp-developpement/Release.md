# Rapport de Release - Sprint1

## Résumé de la Release

Ce sprint a permis de poser les bases de l'application avec des fonctionnalités qui seront réutilisables, notamment celles effectuées pour les tâches. L'objectif principal était de permettre à un utilisateur de se connecter, de gérer ses projets et de pouvoir manager les tâches associées le tout dans une interface utilisateur intuitive.

## Fonctionnalités Livrées

### 1. Gestion des Utilisateurs
- **Connexion** : Un utilisateur peut se connecter à l'application via une interface sécurisée.
- **Inscription** : La création de nouveaux comptes est fonctionnelle avec validation des données utilisateur.
- **Déconnexion** : L'utilisateur peut se déconnecter de son compte ce qui met fin à la session.

### 2. Gestion des Projets
- **Création de Projets** : Les utilisateurs peuvent créer de nouveaux projets.
- **Visualisation des Projets** : Une interface dédiée affiche les projets associés à un utilisateur.
- **Gestion des Projets** : Chaque projet est entièrement gérable, avec une interface afin de gérer son contenu (seules les tâches sont fonctionnelles pour le moment).

### 3. Gestion des Tâches
- **Ajout de Tâches** : Les utilisateurs peuvent ajouter des tâches à un projet spécifique.
- **Modification de Tâches** : Les tâches peuvent être éditées pour ajuster leur contenu ou leur statut.
- **Suppression de Tâches** : Une fonctionnalité permet de supprimer les tâches non désirées.
- **Liste Interne des Tâches** : Chaque projet dispose d'une vue organisée des tâches qui lui sont associées.

### 4. Frontend Interactif et Logique
- **Interface Dynamique** : L'ensemble de cette étape est présenté dans une interface utilisateur avec un design simpliste mais efficace afin de pouvoir pour le moment plus se concentrer sur les bases du projet.
- **Navigation Intuitive** : Une navigation fluide entre les différentes pages (connexion, projets, tâches).

## Développements Techniques

### Backend
- **Routes** :
  - Mise en place des routes pour gérer la connexion, les projets et les tâches.
  - Gestion des requêtes `GET`, `POST`, `PUT`, et `DELETE` pour les projets et tâches.
- **Architecture** :
  - Les fichiers backend sont divisés afin de séparer la logique utilisateur, projet et tâche.
- **Base de Données Locale** :
  - Implémentation d'une base de données en mémoire afin de stocker temporairement les utilisateurs, projets et tâches.

### Frontend
- **Fichiers `.ejs`** :
  - Création des templates pour chaque page.
  - Intégration des données de manière dynamique grâce aux variables transmises par le backend et récupérées dans les fichiers .ejs plutôt que simples .html.
- **Améliorations UX** :
  - Messages de confirmation pour les actions utilisateur (uniquement sous forme de console.log pour le moment).

# Rapport de Release - Sprint2

# Rapport de Release - Sprint3

# Rapport de Release - Sprint4