## Besoins Fonctionnels
#### Tâches
- [ ] **Création de Tâches** : L'utilisateur peut créer une nouvelle tâche avec un titre et une description.
- [ ] **Liste des Tâches** : L'utilisateur peut voir toutes ses tâches sous forme de liste.
- [ ] **Marquer une Tâche comme Complète** : L'utilisateur peut marquer une tâche comme à faire, en cours de dev, à tester, en cours de test, à valider, en cours de validation, à mettre en production, mise en production effectuée.
- [ ] **Suppression de Tâches** : L'utilisateur peut supprimer une tâche.
- [ ] **Affectation de Tâches** : L'utilisateur peut affecter une tâche à un développeur.
- [ ] **Association de Tâches à une Issue** : L'utilisateur peut associer différentes tâches à une issue spécifique. 
- [ ] **Filtrage des Tâches** : L'utilisateur peut filtrer les tâches par statut (toutes, à faire, en cours de dev, à tester, en cours de test, à valider, en cours de validation, à mettre en production, mise en production effectuée).
- [ ] **Affectation de dépendance de Tâches** : L'utilisateur peut lier une tâche à une autre pour créer un système de dépendance (A dépendante de B).
- [ ] **Date de fin de Tâches** : L'utilisateur doit affecter à une tâche une date de fin.
- [ ] **Estimation de durée d'une Tâches** : L'utilisateur peut affecter l'éstimation de la durée d'une tâche.
- [ ] **Commenter une Tâche** : L'utilisateur peut ajouter un commentaire à une tâche.
- [ ] **Historique d'une Tâche** : L'utilisateur peut accéder à l'historique d'une tâche (date de changement de statut).
- [ ] **Modifier une Tâche** : L'utilisateur peut modifier le contenu d'une tâche.

#### Issues
- [ ] **Création de Issues** : L'utilisateur peut créer une nouvelle issues avec une description.
- [ ] **Liste des Issues** : L'utilisateur peut voir toutes ses issues sous forme de liste.
- [ ] **Avoir un statut Marquer une Issue comme Complète** : L'utilisateur peut marquer une issue comme en cours, terminée.
- [ ] **Association d'Issues à une Release** : L'utilisateur peut associer différentes issues à une release spécifique.
- [ ] **Suppression de Issues** : L'utilisateur peut supprimer une issue.
- [ ] **Filtrage des Issues** : L'utilisateur peut filtrer les issues par statut (toutes, terminée, en cours).
- [ ] **Modifier une Issues** : L'utilisateur peut modifier le contenu d'une issues.

#### Releases
- [ ] **Création de Releases** : L'utilisateur peut créer une nouvelle release avec un titre, une description, et une date de sortie prévue.
- [ ] **Liste des Releases** : L'utilisateur peut voir toutes ses releases sous forme de liste.
- [ ] **Gestion du statut des Releases** : L'utilisateur peut marquer une release comme en cours, prête ou déployée.
- [ ] **Filtrage des Releases** : L'utilisateur peut filtrer les releases par statut (toutes, en cours, prête ou déployée).
- [ ] **Vue Détail d'une Release** : L'utilisateur peut voir les détails d'une release, incluant la liste des issues associées.
- [ ] **Suppression de Releases** : L'utilisateur peut supprimer une release.
- [ ] **Modifier une Release** : L'utilisateur peut modifier le contenu d'une release.

#### Tests
- [ ] **Création de Tests** : L'utilisateur peut créer un nouveau test avec un titre, le ou les noms des fichiers sur lesquels il porte ainsi qu'une description.
- [ ] **Liste des Tests** : L'utilisateur peut voir tous ses tests sous forme de liste.
- [ ] **Association de Tests à une Issue** : L'utilisateur peut associer différents tests à un issue spécifique.
- [ ] **Suppression de Tests** : L'utilisateur peut supprimer un test.
- [ ] **Modifier un Test** : L'utilisateur peut modifier le contenu d'un test.

#### Documentation
- [ ] **Création d'une Documentation** : L'utilisateur peut créer une nouvelle documentation avec un titre, sa date de validité ainsi que son contenu.
- [ ] **Liste des Documentations** : L'utilisateur peut voir toutes ses documentations sous forme de liste.
- [ ] **Association d'une Documentation à une Release** : L'utilisateur peut associer une documentation à une release spécifique.
- [ ] **Suppression de Documentations** : L'utilisateur peut supprimer une documentation.
- [ ] **Modifier une Documentation** : L'utilisateur peut modifier le contenu d'une documentation.

## Besoins Non Fonctionnels
- [ ] **Identification des Issues** : Chaque issue peut être identifiée de façon unique.
- [ ] **Performance** : L'application doit se charger en moins de 2 secondes.
- [ ] **Performance** : L'application doit pouvoir gérer un nombre croissant d'utilisateurs et de tâches sans dégradation des performances. 
- [ ] **Sécurité** : Les données des utilisateurs doivent être sécurisées par un système d'authentification.
- [ ] **Accessibilité** : L'application doit être accessible aux personnes ayant des handicaps.
- [ ] **Interface Utilisateur** : L'application doit avoir une interface intuitive et conviviale.
- [ ] **Documentation** : La documentation technique et utilisateur doit être fournie pour faciliter la maintenance et l'utilisation de l'application.