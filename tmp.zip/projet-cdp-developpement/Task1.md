# Liste des Tâches effectué durant le sprint 1.

## 1. Gestion de la Connexion

### Création des Pages HTML

- **ID: GCP001** - Créer une page d'accueil avec possibilité de connexion ou d'inscription.
- **ID: GCP002** - Créer une page de connexion avec un champ "nomutilisateur" et un champ "motdepasse".
- **ID: GCP003** - Créer une page d'inscription avec un champ "nomutilisateur" et un champ "motdepasse".
- **ID: GCP004** - Faire le lien entre ces trois pages (navigation et redirections).

**Responsable**: Quentin  

---

### Enregistrement d'un Compte

- **ID: EAC001** - Développer des classes JS permettant l'enregistrement d'un compte en local.
- **ID: EAC002** - Développer des classes JS permettant l'ajout de projets à un compte spécifique.
- **ID: EAC003** - Enregistrer en local un nouveau compte.

**Responsable**: Quentin  

---

### Connexion et Déconnexion

- **ID: CAC001** - Rendre l'accès à un compte déjà créé possible avec les bonnes informations de connexion.  
  **Dépendances**: EAC003 doit être terminée.

- **ID: CAC002** - Rediriger vers l'accueil utilisateur après la connexion.  
  **Dépendances**: CAC001 doit être terminée.

- **ID: DAC001** - Rendre la déconnexion d'un compte possible.  
  **Dépendances**: CAC002 doit être terminée.

- **ID: DAC002** - Rediriger vers la page d'accueil après la déconnexion.  
  **Dépendances**: DAC001 doit être terminée.

**Responsable**: Quentin  

---

## 2. Gestion des Tâches

### Création de la Structure de Tâches

- **ID: CT001** - Créer une classe Task qui représente une tâche avec un titre et une description.
- **ID: CT002** - Créer une classe TaskBDD pour gérer une liste de tâches.  
  **Dépendances**: CT001 doit être terminée.

- **ID: CT003** - Ajouter une méthode `addTask(title, description)` dans TaskBDD.  
  **Dépendances**: CT002 doit être terminée.

- **ID: CT004** - Vérifier que le titre et la description ne sont pas vides avant l'ajout.  
  **Dépendances**: CT003 doit être terminée.

- **ID: CT005** - Ajouter la tâche à la liste et enregistrer un log de confirmation.  
  **Dépendances**: CT004 doit être terminée.

**Responsable**: Tarik  

---

### Gestion des Tâches Complètes et Suppression

- **ID: LT001** - Implémenter `getAllTasks()` pour renvoyer la liste complète des tâches.  
  **Dépendances**: CT005 doit être terminée.

- **ID: LT002** - Afficher la liste des tâches dans la console de manière organisée.  
  **Dépendances**: LT001 doit être terminée.

- **ID: MTC001** - Ajouter une méthode `updateTaskStatus(taskId, status)` pour changer le statut de la tâche.  
  **Dépendances**: LT002 doit être terminée.

- **ID: MTC002** - Définir des statuts valides pour les tâches.  
  **Dépendances**: MTC001 doit être terminée.

- **ID: ST001** - Créer `removeTask(taskId)` pour supprimer une tâche de TaskBDD.  
  **Dépendances**: MTC002 doit être terminée.

- **ID: ST002** - Vérifier l'existence de la tâche avant de la supprimer.  
  **Dépendances**: ST001 doit être terminée.

**Responsable**: Tarik  

---

### Gestion Avancée des Tâches

- **ID: AT001** - Ajouter `assignTaskToDeveloper(taskId, developerName)` pour assigner une tâche à un développeur.  
  **Dépendances**: ST002 doit être terminée.

- **ID: ATI001** - Créer `linkTaskToIssue(taskId, issueId)` pour associer une tâche à une issue.  
  **Dépendances**: AT001 doit être terminée.

- **ID: FT001** - Implémenter `filterTasksByStatus(status)` pour filtrer les tâches par statut.  
  **Dépendances**: ATI001 doit être terminée.

- **ID: DT001** - Ajouter `setTaskDependency(taskId, dependentTaskId)` pour définir les dépendances.  
  **Dépendances**: FT001 doit être terminée.

- **ID: DFT001** - Ajouter `setTaskDeadline(taskId, deadline)` pour définir une date de fin.  
  **Dépendances**: DT001 doit être terminée.

- **ID: EDT001** - Ajouter `setTaskDurationEstimate(taskId, duration)` pour estimer la durée d'une tâche.  
  **Dépendances**: DFT001 doit être terminée.

- **ID: CTC001** - Implémenter `addCommentToTask(taskId, comment)` pour ajouter des commentaires.  
  **Dépendances**: EDT001 doit être terminée.

- **ID: HT001** - Ajouter `getTaskHistory(taskId)` pour voir l'historique des statuts.  
  **Dépendances**: CTC001 doit être terminée.

- **ID: MT001** - Créer `editTask(taskId, newTitle, newDescription)` pour modifier le contenu d'une tâche.  
  **Dépendances**: HT001 doit être terminée.

**Responsable**: Tarik  

---

## 3. Configuration Initiale des Routes Backend

- **ID: RCFG001** - Configurer un serveur Node.js avec Express.
  - Installer les dépendances nécessaires (Express, ejs, body-parser, etc.).

**Responsable**: Quentin

---

## 4. Gestion des Pages et Liaison des Routes

### Liaison des Pages de Connexion, Inscription et Accueil

- **ID: RL001** - Créer les route minimale pour chacunes de ces pages.
  - indexRoutes
  - registerRoutes
  - loginRoutes
  - editProjectRoutes
  - userRoutes
  - projectRoutes
  - projectsRouter

- **ID: RL002** - Utiliser les differentes methodes de recuperation de donnée pour chacune en liant les fihciers de rendu frontend. (.ejs , ou .html)
    Exemple :
  - Méthode: `GET /login`
  - Fichier associé: `login.ejs`.

**Responsable**: Quentin - Tarik

---

