# Scénarios de test

## Tâches

[Tests gherkin des tâches](Gherkin/TasksTests.md)

## Login

[Tests gherkin de la partie connexion](Gherkin/LoginTests.md)

## Issues

[Tests gherkin des Issues](Gherkin/IssuesTests.md)

## Documentation

[Tests gherkin de la documentation](Gherkin/DocumentationTests.md)

## Releases

[Tests gherkin des releases](Gherkin/ReleaseTests.md)
