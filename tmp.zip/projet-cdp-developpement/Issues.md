# Issues (User Story)

### Connexion

- **US0** En tant que visiteur, je veux pouvoir créer un compte afin de pouvoir accéder à la plateforme.
- **US1** En tant que visiteur, je veux pouvoir me connecter à mon compte afin de pouvoir accéder à mes projets.
- **US2** En tant qu'utilisateur, je veux pouvoir me déconnecter de mon compte afin de quitter ma session actuelle.

### Tâches (+ Tests)

- **US3** En tant qu'utilisateur, je veux pouvoir créer une nouvelle tâche avec un titre et une description afin d'organiser au mieux le travail à réaliser.
- **US4** En tant qu'utilisateur, je peux identifier une tâche grâce à un numéro unique afin de plus facilement se repérer.
- **US5** En tant qu'utilisateur, je veux voir toutes mes tâches sous forme de liste afin d'avoir une vue d'ensemble du travail à faire.
- **US6** En tant qu'utilisateur, je veux pouvoir marquer une tâche comme à faire, en cours de dev, à tester, en cours de test, à valider, en cours de validation, à mettre en production ou mise en production effectuée.
- **US7** En tant qu'utilisateur, je veux pouvoir associer différentes tâches à une issue spécifique afin de respecter au mieux la hiérarchie naturelle d'une conduite de projet. 
- **US8** En tant qu'utilisateur, je veux pouvoir supprimer une tâche afin de garder ma liste de tâches propre et pertinente.
- **US9** En tant qu'utilisateur, je veux pouvoir affecter une tâche à un développeur afin de répartir le travail efficacement.
- **US10** En tant qu'utilisateur, je veux filtrer mes tâches par statut afin d'avoir une vue plus localisée.
- **US11** En tant qu'utilisateur, je veux lier une tâche à une autre afin de gérer les dépendances entre tâches.
- **US12** En tant qu'utilisateur, je veux pouvoir affecter une date de fin à une tâche pour planifier mon travail de manière efficace.
- **US13** En tant qu'utilisateur, je veux pouvoir estimer la durée d'une tâche pour mieux gérer mon temps et mes ressources.
- **US14** En tant qu'utilisateur, je veux pouvoir ajouter des commentaires à une tâche afin de discuter des détails, relever des points problématiques, indiquer quelles fonctionnalités ont été testées ou non.
- **US15** En tant qu'utilisateur, je veux accéder à l'historique d'une tâche afin de voir les changements de statut au fil du temps.
- **US16** En tant qu'utilisateur, je veux pouvoir modifier le contenu d'une tâche afin de mettre à jour les changements nécessaires.

### Issues

- **US17** En tant qu'utilisateur, je veux pouvoir créer une nouvelle issue avec une description afin d'organiser au mieux mon travail.
- **US18** En tant qu'utilisateur, je peux identifier une issue grâce à un numéro unique afin de plus facilement se repérer.
- **US19** En tant qu'utilisateur, je veux voir toutes mes issues sous forme de liste afin d'avoir une vue d'ensemble du travail à faire.
- **US20** En tant qu'utilisateur, je veux pouvoir marquer une issue comme en cours ou terminée afin de suivre son avancement.
- **US21** En tant qu'utilisateur, je veux pouvoir associer différentes issues à une release spécifique afin d'indiquer au mieux la hiérarchie de la production logicielle.
- **US22** En tant qu'utilisateur, je veux pouvoir supprimer une issue afin de garder ma liste d'issues propre et pertinente.
- **US23** En tant qu'utilisateur, je veux filtrer mes issues par statut afin d'avoir une vue plus localisée.
- **US24** En tant qu'utilisateur, je veux pouvoir modifier le contenu d'une issue afin de mettre à jour les changements nécessaires.

### Documentation

- **US25** En tant qu'utilisateur, je veux créer une nouvelle documentation avec un titre, une date de validité et du contenu afin de référencer les informations importantes et nécessaires.
- **US26** En tant qu'utilisateur, je veux voir toutes mes documentations sous forme de liste afin d'avoir une vue d'ensemble.
- **US27** En tant qu'utilisateur, je veux pouvoir associer une documentation à une release spécifique afin de fournir la bonne documentation à la bonne version.
- **US28** En tant qu'utilisateur, je veux pouvoir supprimer une documentation pour gérer mes informations.
- **US29** En tant qu'utilisateur, je veux pouvoir modifier le contenu d'une documentation pour mettre à jour les informations.

### Releases

- **US30** En tant qu'utilisateur, je veux pouvoir créer une nouvelle release avec un titre, une description, un numéro de version et une date de sortie prévue afin de planifier le déploiement de nouvelles fonctionnalités.
- **US31** En tant qu'utilisateur, je veux voir toutes mes releases sous forme de liste afin d'avoir une vue d'ensemble des versions déployées.
- **US32** En tant qu'utilisateur, je veux pouvoir marquer une release comme en cours, prête ou déployée afin de suivre le statut de mes versions.
- **US33** En tant qu'utilisateur, je veux filtrer mes releases par statut afin d'avoir une vue plus localisée.
- **US34** En tant qu'utilisateur, je veux voir les détails d'une release, y compris la liste des issues associées, afin de comprendre le contenu de chaque version.
- **US35** En tant qu'utilisateur, je veux pouvoir supprimer une release afin de garder ma liste de releases propre et pertinente.
- **US36** En tant qu'utilisateur, je veux pouvoir modifier le contenu d'une release afin de mettre à jour les informations nécessaires.
