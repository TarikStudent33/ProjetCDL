# Contenu du Sprint1

## Partie Conduite de Projet 

- Réorganisations des tâches (Responsable, temps estimé...,  (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Tasks.md)
- Task1.md qui documente l'ensemble des tâches réalisées au cours de ce Sprint (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Task1.md)
- Release.md qui documente la Release associée à ce Sprint (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Release.md)
- Documentation.md (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Documentation.md)

## Partie Code
- Architecture réorganisée afin d'être plus cohérente (dossiers routes, templates, views, css)
- Création de notre base de données locale ainsi que de l'ensemble des classes de notre application (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/code/classes.js)
- Création des différents formulaires/pages d'accueil HTML (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/code/templates)
- Gestion des utilisateurs (inscription/connexion/déconnexion...)
- Création/Suppression de projets associés à un compte
- Création/Suppression de tâches liées à un projet
- Visualisation des Projets
- Modification de Tâches
- Liste Interne des Tâches
- Messages de confirmation pour les actions utilisateur (uniquement sous forme de console.log pour le moment).