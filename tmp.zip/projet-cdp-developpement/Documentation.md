# Documentation de notre application web de gestion de projet

## Mode d'emploi utilisateur

### Lancement de l'application

depuis /code vous pouvez au choix :  

- npm install express body-parser express-session  
node .\server.js    
ouvrez http://localhost:3000/

- exécutez setup.sh qui regroupe ces différentes commandes :  
./setup.sh  
ouvrez http://localhost:3000/

### Inscription/Connexion

Créez un compte afin d'utiliser l'application.  
Connectez-vous à ce dernier.

### Navigation

Vous pouvez créer de nouveaux projets depuis le boutton "Créer un projet" à la page d'accueil utilisateur ou depuis l'onglet "Projets".  
Vous pouvez parcourir les différents projets en allant dans ce même onglet.  
Vous pouvez également en supprimer depuis ce même onglet. 

## Mode d'emploi administrateur

### Compte administrateur

Vous pouvez accéder à un compte administrateur afin de tester plus rapidement les fonctionnalités sans ravoir à créer un compte (étant donné que notre BDD se relance en même temps que le server).  
user : root  
pw : root

### Ajouter de nouvelles fonctionnalités

Vous pouvez rajouter des routes dans le dossier routes (dépôt/code/routes/).  
Modifiez le code du server (dépôt/code/server.js) pour qu'il les prennent en compte.  
N'oubliez bien sûr pas d'ajouter vos fichiers templates associés à vos routes nouvellement ajoutées.   

### Supprimer des fonctionnalités

Vous pouvez supprimer des routes dans le dossier routes (dépôt/code/routes/).  
Modifiez le code du server (dépôt/code/server.js) pour qu'il ne les prennent plus en compte.  
N'oubliez bien sûr pas de supprimer vos fichiers templates associés à vos anciennes routes.   

## Architecture du Système

Architecture NodeJS :
- Server : dépôt/code/server.js
- Défnition de l'ensemble des classes (BDD...) : dépôt/code/merge.js
- Routes : dépôt/code/routes
- CSS : dépôt/code/css
- HTML : dépôt/code/templates
- views : dépôt/code/views

## Sécurité

## Tests

## Mises à Jour et Versions

### Historique des versions

voir Release.md (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Release.md)

### Notes de version

voir Release.md (https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release/-/blob/main/Release.md)

## Ressources et Références

## Maquettes 

![HomePage maquette](Img/MaquetteHomepage.png)
