const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();
const globalBDD = require('../merge.js');
var referer = null;

// Route pour afficher la page de connexion
router.get('/', (req, res) => {
    referer = req.get('Referer');
    res.render('creds', { username : globalBDD.accountsBDD.account_logged.getUsername() });
});

// Route pour traiter la soumission du formulaire de connexion
router.post('/', (req, res) => {
    
});

// Route pour traiter la soumission du formulaire de connexion
router.get('/out', (req, res) => {
    res.redirect(referer);
});

module.exports = router;
