const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();
const globalBDD = require('../merge.js');

// Route pour afficher la page d'enregistrement
router.get('/', (req, res) => {
    const errorMessage = req.query.error || '';
    fs.readFile(path.join(__dirname, '../templates/register.html'), 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Erreur lors de la lecture du fichier.');
        }

        // Injecte le message d'erreur dans le HTML
        const result = data.replace(/{{errorMessage}}/g, errorMessage);
        res.send(result);
    });
});

// Route pour traiter la soumission du formulaire d'enregistrement
router.post('/', (req, res) => {
    const { username, password} = req.body;
    if (!globalBDD.accountsBDD.addAccount(username, password)){
        return res.redirect('/register?error=Identifiant déjà pris');
    }

    return res.redirect('/login');
});


module.exports = router;
