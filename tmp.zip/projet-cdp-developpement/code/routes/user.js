const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();
const globalBDD = require('../merge');

// Route pour afficher la page de l'utilisateur
router.get('/', (req, res) => {
    const username = req.query.username;
    
    if (!username) {
        return res.status(400).send('Nom d\'utilisateur requis');
    }

    // Récupérer tous les projets où l'utilisateur est membre
    const userProjects = globalBDD.projectsBDD.projects.filter(project => 
        project.members.includes(username)
    );

    // Pour chaque projet, récupérer les tâches assignées à l'utilisateur
    const projectsWithTasks = userProjects.map(project => ({
        id: project.id,
        name: project.projectname,
        description: project.description,
        tasks: project.tasks.filter(task => task.developer === username)
    }));

    res.render('userpage', { username, projectsWithTasks });
});

// Route pour la déconnexion
router.get('/logout', (req, res) => {
    req.session.user = null;
    const username = globalBDD.accountsBDD.account_logged.getUsername();
    globalBDD.accountsBDD.logoutAccount();
    res.render('logout', { username: username });
});

router.post('/logout', (req, res) => {
    //res.redirect('/');
});

module.exports = router;

