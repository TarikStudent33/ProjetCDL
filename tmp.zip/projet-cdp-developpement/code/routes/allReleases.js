const express = require('express');
const router = express.Router();
const globalBDD = require('../merge');

// Route pour afficher toutes les releases
router.get('/:id', (req, res) => {
    const releases = globalBDD.projectsBDD.projects.reduce((acc, project) => {
        return acc.concat(project.releases.map(release => ({
            project: project.projectname,
            projectId: project.id,
            id: release.id,
            title: release.title,
            description: release.description,
            status: release.status,
            version: release.version
        })));
    }, []);

    const projectId = req.params.id;
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }
    const proj_name = project.getName();
    res.render('allReleases', { releases: releases, id: projectId, pname: proj_name });
});

// Route racine
router.get('/', (req, res) => {
    res.redirect('/projects');
});

module.exports = router;
