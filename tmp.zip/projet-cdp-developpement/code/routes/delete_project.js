const express = require('express');
const path = require('path');
const globalBDD = require('../merge');
const { glob } = require('fs');
const router = express.Router();

router.post('/:id', (req, res) => {
    const projectId = req.params.id;
    globalBDD.projectsBDD.removeProject(projectId);
    return res.redirect(`/projects`);
});


module.exports = router;
