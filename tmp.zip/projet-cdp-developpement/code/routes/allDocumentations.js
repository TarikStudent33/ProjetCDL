const express = require('express');
const router = express.Router();
const globalBDD = require('../merge');

// Route pour afficher toutes les documentations
router.get('/:id', (req, res) => {
    const documentations = globalBDD.projectsBDD.projects.reduce((acc, project) => {
        return acc.concat(project.documentations.map(doc => ({
            project: project.projectname,
            title: doc.title,
            content: doc.content,
            validityDate: doc.validityDate,
            projectId: project.id
        })));
    }, []);

    const projectId = req.params.id;
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }
    const proj_name = project.getName();
    res.render('allDocumentations', { documentations: documentations, id: projectId, pname: proj_name });
});

// Route racine
router.get('/', (req, res) => {
    res.redirect('/projects');
});

module.exports = router;
