const express = require('express');
const path = require('path');
const globalBDD = require('../merge');
const { glob } = require('fs');
const router = express.Router();

var mem_list = [];

router.get('/', (req, res) => {
    const errorMessage = req.query.error || '';
    res.sendFile(path.join(__dirname, '../templates/formulaire_projet.html'));
});

router.post('/', (req, res) => {
    const { projectname, description, projectmembers} = req.body;
    console.log("list_mem before addP :" + mem_list);
    globalBDD.projectsBDD.addProject(projectname,description, globalBDD.accountsBDD.account_logged.getUsername(),mem_list);
    mem_list = [];
    console.log("Members wanted : " + mem_list);
    const errorMessage = req.query.error || '';

    return res.redirect(`/projects`);
});

router.post('/addmem', (req, res) => {
    const member_to_add = req.body.projectmembers;
    console.log("Members wanted : " + member_to_add);
    mem_list.push(member_to_add);
    res.json({ message: 'Demande d + ' + "'" + 'ajout de : ' + member_to_add + " au projet effectuée." });
});

module.exports = router;
