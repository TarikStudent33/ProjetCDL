const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();
const globalBDD = require('../merge.js');

// Route pour afficher la page de connexion
router.get('/', (req, res) => {
    const errorMessage = req.query.error || '';
    console.log(errorMessage + " = errorMSG");
    fs.readFile(path.join(__dirname, '../templates/login.html'), 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Erreur lors de la lecture du fichier.');
        }

        // Injecte le message d'erreur dans le HTML
        const result = data.replace(/{{errorMessage}}/g, errorMessage);
        res.send(result);
    });
});

// Route pour traiter la soumission du formulaire de connexion
router.post('/', (req, res) => {
    const { username, password } = req.body;
    if (globalBDD.accountsBDD.connectAccount(username, password)){
        req.session.user = username; 
        return res.redirect(`/user?username=${globalBDD.accountsBDD.account_logged.getUsername()}`);
    } else {
        return res.redirect('/login?error=Identifiant et/ou motdepasse invalide');
    }
});

// Route pour la déconnexion
router.get('/logout', (req, res) => {
    req.session.user = null;
    const username = globalBDD.accountsBDD.account_logged.getUsername();
    globalBDD.accountsBDD.logoutAccount();
    res.render('logout', { username : username });
});

module.exports = router;
