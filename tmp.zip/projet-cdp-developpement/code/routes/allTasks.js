const express = require('express');
const router = express.Router();
const globalBDD = require('../merge'); // Assurez-vous que `merge.js` contient vos données

// Route pour afficher toutes les tâches
router.get('/:id', (req, res) => {
    const referer = req.get('Referer');
    const tasks = globalBDD.projectsBDD.projects.reduce((acc, project) => {
        return acc.concat(project.tasks.map(task => ({
            project: project.projectname,
            task: task.taskname,
            status: task.status,
            developer: task.developer,
            deadline: task.deadline,
            duration: task.duration,
            dependency: task.dependency,
        })));
    }, []);
    const projectId = req.params.id; 
    console.log("projectId : " + projectId);
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }
    const proj_name = project.getName();
    res.render('allTasks', { tasks : tasks, id : projectId, pname : proj_name });
});

// Route racine
router.get('/', (req, res) => {
    res.redirect('/projects');
});

module.exports = router;
