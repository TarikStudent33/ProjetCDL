const express = require('express');
const router = express.Router();
const path = require('path');
const globalBDD = require('../merge');

router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../templates/projects.html'));
});

router.get('/data', (req, res) => {
    const projects = globalBDD.projectsBDD.projects.map(project => ({
        id: project.id,
        projectname: project.projectname,
        description: project.description,
        founder: project.founder.getUsername(),
        members: project.members.map(member => member.getUsername())
    }));
    res.json(projects);
});

router.post('/', (req, res) => {
    const { id, projectname, description } = req.body;
    const project = globalBDD.projectsBDD.projects.find(project => project.id == id);
    console.log(project);
    if (project) {
        project.projectname = projectname;
        project.description = description;
        return res.redirect('/projects/manage_project/' + id);
    }
    return res.status(404).send('Projet non trouvé');
}
);

module.exports = router;
