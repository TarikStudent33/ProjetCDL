const express = require('express');
const router = express.Router();
const path = require('path');
const globalBDD = require('../merge');
const { Tasks, Issues, Documentation, Release} = require('../merge');
const { globalAgent } = require('http');

router.get('/', (req, res) => {
    res.render('projects', {username : globalBDD.accountsBDD.account_logged.getUsername()});
});

router.get('/data', (req, res) => {
    const username = globalBDD.accountsBDD.account_logged.getUsername();
    const projects = globalBDD.projectsBDD.projects
        .filter(project => project.members.some(member => member === username))
        .map(project => ({
        id: project.id,
        projectname: project.projectname,
        description: project.description,
        founder: project.founder,
        members: project.members.map(member => member)
    }));
    res.json(projects);
});

router.post('/', (req, res) => {
    const { id, projectname, description } = req.body;

    if (!id || !projectname) {
        return res.status(404).send('Projet non trouvé');
    }

    return res.redirect(`/projects/manage_project/${id}`);
});

router.get('/allTasks', (req, res) => {
    const tasks = globalBDD.projectsBDD.projects.reduce((acc, project) => {
        return acc.concat(project.tasks.map(task => ({
            project: project.projectname,
            task: task.taskname,
            status: task.status,
            developer: task.developer,
            deadline: task.deadline,
            duration: task.duration,
            dependency: task.dependency
        })));
    }, []);

    res.render('allTasks', { tasks });
});

router.get('/manage_project/:id', (req, res) => {
    const projectId = req.params.id;
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    res.render('manage_project', { project : project, username : globalBDD.accountsBDD.account_logged.getUsername(), id : projectId });
});

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////TASKS/////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

router.get('/manage_project/:id/tasks', (req, res) => {
    const projectId = req.params.id;
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));

    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    res.render('project_tasks', { project });
});

// Ajouter une nouvelle tâche
router.post('/manage_project/:id/tasks/add', (req, res) => {
    const projectId = Number(req.params.id);
    const { newTask } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === projectId);
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const taskId = Date.now();
    const newTaskInstance = new Tasks(newTask, taskId, "Description par défaut", "En cours");
    project.addTask(newTaskInstance);

    res.redirect(`/projects/manage_project/${projectId}/tasks`);
});

// Supprimer une tâche
router.delete('/manage_project/:id/tasks/:taskId', (req, res) => {
    const projectId = req.params.id;
    const taskId = Number(req.params.taskId);

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    project.tasks = project.tasks.filter(task => task.taskid !== taskId);
    res.json({ message: 'Tâche supprimée avec succès' });
});

// Mettre à jour le statut d’une tâche
router.post('/manage_project/:id/tasks/:taskId/status', (req, res) => {
    const { id, taskId } = req.params;
    const { status } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(id));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const task = project.tasks.find(task => task.taskid === Number(taskId));
    if (task) {
        console.log(task);
        task.updateTaskStatus(status);
    }

    res.redirect(`/projects/manage_project/${id}/tasks`);
});

// Assigner une tâche à un développeur
router.post('/manage_project/:id/tasks/:taskId/assign', (req, res) => {
    const { id, taskId } = req.params;
    const { developer } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(id));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const task = project.tasks.find(task => task.taskid === Number(taskId));
    if (task) {
        task.assignTaskToDeveloper(developer);
    }

    res.redirect(`/projects/manage_project/${id}/tasks`);
});

// Ajouter une dépendance à une tâche
router.post('/manage_project/:id/tasks/:taskId/dependency', (req, res) => {
    const { id, taskId } = req.params;
    const { dependencyTaskId } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(id));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const task = project.tasks.find(task => task.taskid === Number(taskId));
    if (task) {
        task.setTaskDependency(dependencyTaskId);
    }

    res.redirect(`/projects/manage_project/${id}/tasks`);
});

// Définir une échéance et une durée estimée pour une tâche
router.post('/manage_project/:id/tasks/:taskId/deadline', (req, res) => {
    const { id, taskId } = req.params;
    const { deadline, duration } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(id));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const task = project.tasks.find(task => task.taskid === Number(taskId));
    if (task) {
        if (deadline) task.setTaskDeadline(new Date(deadline));
        if (duration) task.setTaskDurationEstimate(duration);
    }

    res.redirect(`/projects/manage_project/${id}/tasks`);
});

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////ISSUES////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

// Afficher la liste des issues d'un projet
router.get('/manage_project/:id/issues', (req, res) => {
    const projectId = req.params.id;
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));

    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    res.render('project_issues', { project });
});

// Ajouter une nouvelle issue
router.post('/manage_project/:id/issues/add', (req, res) => {
    const projectId = Number(req.params.id);
    const { description } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === projectId);
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const issueId = Date.now();
    const newIssue = new Issues(issueId, description);
    project.addIssue(newIssue);

    res.redirect(`/projects/manage_project/${projectId}/issues`);
});

// Supprimer une issue
router.delete('/manage_project/:id/issues/:issueId', (req, res) => {
    const projectId = req.params.id;
    const issueId = Number(req.params.issueId);

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    project.issues = project.issues.filter(issue => issue.id !== issueId);
    res.json({ message: 'Issue supprimée avec succès' });
});

// Mettre à jour le statut ou la description d’une issue
router.post('/manage_project/:id/issues/:issueId/update', (req, res) => {
    const { id, issueId } = req.params;
    const { status, description } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(id));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const issue = project.issues.find(issue => issue.id === Number(issueId));
    if (issue) {
        issue.setStatus(status);
        issue.setDescription(description);
    }

    res.redirect(`/projects/manage_project/${id}/issues`);
});

// Assigner une issue à une release
router.post('/manage_project/:id/issues/:issueId/assign_release', (req, res) => {
    const { id, issueId } = req.params;
    const { releaseId } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(id));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const issue = project.issues.find(issue => issue.id === Number(issueId));
    const release = project.releases.find(release => release.id === Number(releaseId));
    if (issue && release) {
        project.associateIssueToRelease(issueId, release);
    }

    res.redirect(`/projects/manage_project/${id}/issues`);
});

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////DOCUMENTATION////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

router.get('/manage_project/:id/documentations', (req, res) => {
    const projectId = req.params.id;
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));

    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    project.documentations = project.documentations || [];
    console.log(project);

    res.render('project_documentations', { project });
});

router.get('/allDocumentations', (req, res) => {
    // Récupérer toutes les documentations de tous les projets
    const allDocs = globalBDD.projectsBDD.projects.reduce((acc, project) => {
        return acc.concat(project.documentations.map(doc => ({
            projectName: project.projectname,
            projectId: project.id,
            ...doc
        })));
    }, []);

    res.render('allDocumentations', { documentations: allDocs });
});

router.post('/manage_project/:id/documentations/add', (req, res) => {
    const projectId = Number(req.params.id);  // Récupère l'ID du projet
    const { title, content, validityDate } = req.body;  // Récupère les données de la documentation

    // Vérification de la validité de la date
    const validDate = new Date(validityDate);
    if (isNaN(validDate.getTime())) {
        return res.status(400).send('Date invalide');  // Si la date est invalide
    }

    // Trouver le projet correspondant à l'ID dans la base de données globale
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === projectId);
    if (!project) {
        return res.status(404).send('Projet non trouvé');  // Si le projet n'existe pas
    }

    // Créer une nouvelle documentation via DocumentationBDD
    const doc = globalBDD.documentationBDD.addDocumentation(title, content, validDate);  // Ajout à la "BDD"

    project.addDocumentation(doc);

    // Redirection vers la page des documentations du projet
    res.redirect(`/projects/manage_project/${projectId}/documentations`);
});

// Supprimer une documentation
router.delete('/manage_project/:id/documentations/:docId', (req, res) => {
    const projectId = req.params.id;
    const docId = Number(req.params.docId);

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    // Suppression de la documentation
    globalBDD.documentationBDD.removeDocumentation(docId);
    
    // Redirection vers la page des documentations du projet
    res.json({ message: 'Documentation supprimée avec succès' });
});

// Mettre à jour une documentation (statut ou description)
router.post('/manage_project/:id/documentations/:docId/update', (req, res) => {
    const { id, docId } = req.params;
    const { title, content, validityDate } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(id));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    // Mise à jour de la documentation
    globalBDD.documentationBDD.updateDocumentation(docId, title, content, validityDate);
    
    // Redirection vers la page des documentations du projet
    res.redirect(`/projects/manage_project/${id}/documentations`);
});

// Assigner une documentation à une release
router.post('/manage_project/:id/documentations/:docId/assign_release', (req, res) => {
    const { id, docId } = req.params;
    const { releaseId } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(id));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const documentation = globalBDD.documentationBDD.documentations.find(doc => doc.id === Number(docId));
    const release = project.releases.find(release => release.id === Number(releaseId));

    if (documentation && release) {
        // Associer la documentation à la release (ajoutez la logique selon votre application)
        console.log(`Documentation ${documentation.title} associée à la release ${release.title}`);
    }

    res.redirect(`/projects/manage_project/${id}/documentations`);
});

router.post('/manage_project/:id/add_member/', (req,res) => {
    const projectId = req.params.id; 
    const newMember = req.body.newMember; 
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }
    project.addMember(newMember);
    res.render('manage_project', { project : project, username : globalBDD.accountsBDD.account_logged.getUsername() });
});

router.post('/manage_project/:id/remove_member/', (req,res) => {
    const projectId = req.params.id; 
    const oldMember = req.body.oldMember; 
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === Number(projectId));
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }
    project.removeMember(oldMember);
    const username = globalBDD.accountsBDD.account_logged.getUsername();
    if (globalBDD.projectsBDD.checkProject(projectId) && oldMember != username){
        res.render('manage_project', { project : project, username : username });
    } else if (oldMember == username) {
        res.render('projects', { username : username });
    }
});

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////// RELEASES ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

// Liste des releases pour un projet donné
router.get('/manage_project/:id/releases', (req, res) => {
    const projectId = Number(req.params.id);
    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === projectId);

    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    project.releases = project.releases || [];
    console.log(project);

    res.render('project_releases', { project });
});

// Ajouter une nouvelle release à un projet
router.post('/manage_project/:id/releases/add', (req, res) => {
    const projectId = Number(req.params.id);
    const { title, description, releaseDate } = req.body;

    // Validation de la date
    const validDate = new Date(releaseDate);
    if (isNaN(validDate.getTime())) {
        return res.status(400).send('Date invalide');
    }

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === projectId);
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    // Ajout d'une nouvelle release
    const release = new Release(Date.now(), title, description, validDate);
    project.releases.push(release);

    // Redirection
    res.redirect(`/projects/manage_project/${projectId}/releases`);
});

// Supprimer une release
router.delete('/manage_project/:id/releases/:releaseId', (req, res) => {
    const projectId = Number(req.params.id);
    const releaseId = Number(req.params.releaseId);

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === projectId);
    if (!project) {
        return res.status(404).json({ message: 'Projet non trouvé' });
    }

    // Trouver l'index de la release à supprimer
    const releaseIndex = project.releases.findIndex(release => release.id === releaseId);
    if (releaseIndex === -1) {
        return res.status(404).json({ message: 'Release non trouvée' });
    }

    // Supprimer la release
    project.releases.splice(releaseIndex, 1);

    res.status(200).json({ message: 'Release supprimée avec succès' });
});

// Mettre à jour une release
router.post('/manage_project/:id/releases/:releaseId/update', (req, res) => {
    const projectId = Number(req.params.id);
    const releaseId = Number(req.params.releaseId);
    const { title, description, releaseDate } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === projectId);
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const release = project.releases.find(release => release.id === releaseId);
    if (!release) {
        return res.status(404).send('Release non trouvée');
    }

    // Mise à jour des détails de la release
    release.setDetails(title, description, new Date(releaseDate));

    // Redirection
    res.redirect(`/projects/manage_project/${projectId}/releases`);
});

// Assigner une issue à une release
router.post('/manage_project/:id/releases/:releaseId/assign_issue', (req, res) => {
    const projectId = Number(req.params.id);
    const releaseId = Number(req.params.releaseId);
    const { issueId } = req.body;

    const project = globalBDD.projectsBDD.projects.find(proj => proj.id === projectId);
    if (!project) {
        return res.status(404).send('Projet non trouvé');
    }

    const release = project.releases.find(release => release.id === releaseId);
    const issue = project.issues.find(issue => issue.id === Number(issueId));

    if (!release) {
        return res.status(404).send('Release non trouvée');
    }
    if (!issue) {
        return res.status(404).send('Issue non trouvée');
    }

    // Assigner l'issue à la release
    release.addIssue(issue);

    // Redirection
    res.redirect(`/projects/manage_project/${projectId}/releases`);
});

// Route pour afficher le formulaire de création de projet
router.get('/create_project', (req, res) => {
    res.render('create_project');
});

// Route pour la recherche d'utilisateurs
router.get('/users/search', (req, res) => {
    const searchQuery = req.query.q.toLowerCase();
    // Récupérer tous les utilisateurs sauf l'utilisateur connecté
    const currentUser = globalBDD.accountsBDD.account_logged.getUsername();
    const allUsers = globalBDD.accountsBDD.accounts
        .filter(account => 
            account.username.toLowerCase().includes(searchQuery) &&
            account.username !== currentUser
        )
        .map(account => ({
            username: account.username
        }));
    res.json(allUsers);
});

// Route pour créer un nouveau projet
router.post('/create_project', (req, res) => {
    const { projectname, description, members } = req.body;
    const founder = globalBDD.accountsBDD.account_logged.getUsername();
    
    try {
        const membersList = members ? JSON.parse(members) : [];
        // Suppression de cette ligne car le fondateur est déjà ajouté dans le constructeur de Project
        // if (!membersList.includes(founder)) {
        //     membersList.push(founder);
        // }

        // Utiliser la fonction addProject de la BDD
        globalBDD.projectsBDD.addProject(projectname, description, founder, membersList);
        
        res.redirect('/projects');
    } catch (error) {
        console.error('Erreur lors de la création du projet:', error);
        res.status(400).send('Erreur lors de la création du projet');
    }
});

module.exports = router;
