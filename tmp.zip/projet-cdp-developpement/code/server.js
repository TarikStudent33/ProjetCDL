const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const accountsBDD = require('./merge.js');
const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views')); // Le dossier contenant les vues

app.use(session({
    secret: 'pvk_gdp_sess',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); // Ajouter le support pour JSON
app.use('/css', express.static(path.join(__dirname, 'css')));

// Fonction pour vérifier si l'utilisateur est connecté
function checkAuth(req, res, next) {
    if (!req.session || !req.session.user) {
        return res.redirect('/login');
    }
    next();
}

const indexRoutes = require('./routes/index');
const registerRoutes = require('./routes/register');
const loginRoutes = require('./routes/login');

app.use('/', indexRoutes);
app.use('/register', registerRoutes);
app.use('/login', loginRoutes);
app.use(checkAuth);

// Ajout des routes pour les projets
const editProjectRoutes = require('./routes/editProject');
const userRoutes = require('./routes/user');
const deleteRoutes = require('./routes/delete_project');
const projectsRouter = require('./routes/projectsRouter');
const helpRoutes = require('./routes/help');
const allTasks = require('./routes/allTasks');
const allIssues = require('./routes/allIssues');
const credsRoutes = require('./routes/creds');
const allReleases = require('./routes/allReleases');
const allDocumentations = require('./routes/allDocumentations');

app.use('/user', userRoutes);
app.use('/logout', userRoutes);
app.use('/delete_project', deleteRoutes);
app.use('/projects', projectsRouter);
app.use('/edit_project', editProjectRoutes);
app.use('/help',helpRoutes);
app.use('/allTasks',allTasks);
app.use('/allIssues',allIssues);
app.use('/creds',credsRoutes);
app.use('/allReleases',allReleases);
app.use('/allDocumentations', allDocumentations);

// Démarrage du serveur
app.listen(PORT, () => {
    console.log(`Serveur en écoute sur http://localhost:${PORT}`);
});
