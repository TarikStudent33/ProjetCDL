// fichier de classes

class Account {
    constructor(username, password) {
        this.username = username;
        this.password = password;
    }

    getUsername(){
        return this.username;
    }

    displayInfo() {
        console.log(`Nom d'utilisateur: ${this.username}`);
    }

    checkCredentials(inputUsername, inputPassword) {
        return this.username === inputUsername && this.password === inputPassword;
    }
}

class Project {
    static id = 0;

    constructor(name, description, founder, mem_list){
        Project.id += 1;
        this.id = Project.id;
        this.projectname = name;
        this.description = description;
        this.founder = founder;
        this.members = [];
        this.tasks = [];
        this.issues = [];
        this.documentations = [];
        this.left = false;
        this.addMember(founder);
        this.addMembersFromList(mem_list);
    }

    getId(){
        return this.id;
    }

    getName(){
        return this.projectname;
    }

    addMember(username){
        if (globalBDD.accountsBDD.findAccount(username)){
            this.members.push(username);
            return true;
        }
        return false;
    }

    addMembersFromList(members_list){
        console.log("HERE");
        console.log("Liste : " + members_list);
        members_list.forEach(member => {
            console.log("member traité : " + member);
            this.addMember(member);
        });
    }

    removeMember(username) {
        const index = this.members.indexOf(username);
        if (index > -1) {
            this.members.splice(index, 1);
        }
        if (this.members.length == 0) this.left = true;
    }

    projectIsLeft(){
        return this.left;
    }

    // Nouvelle méthode pour ajouter une tâche
    addTask(task) {
        this.tasks.push(task);
    }

    addIssue(issue) {
        this.issues.push(issue);
    }

    addDocumentation(documentation) {
        this.documentations.push(documentation);
    }

    // Nouvelle méthode pour supprimer une tâche par son ID
    removeTask(taskId) {
        const index = this.tasks.findIndex(task => task.getId() === taskId);
        if (index !== -1) {
            this.tasks.splice(index, 1);
        }
    }

    removeIssue(issueId) {
        const index = this.issues.findIndex(issue => issue.getId() === issueId);
        if (index !== -1) {
            this.issues.splice(index, 1);
        }
    }

    removeDocumentation(docId) {
        const index = this.documentations.findIndex(doc => doc.getId() === docId);
        if (index !== -1) {
            this.documentations.splice(index, 1);
        }
    }

    displayMembers(){
        for (let i = 0; i < this.members.length; i++) {
            console.log(this.members[i].getUsername());
        }
    }
}



const TaskStatus = {
    0: "À faire",
    1: "En cours de développement",
    2: "À tester",
    3: "En cours de test",
    4: "À valider",
    5: "En cours de validation",
    6: "À mettre en production",
    7: "Mise en production effectuée"
};

class Tasks {
    constructor(taskname, taskid, taskdescription, status){
        this.taskid = taskid;
        this.status = status;
        this.taskname = taskname;
        this.taskdescription = taskdescription;
        this.comments = [];
        this.developer = "";
        this.issue = "";
        this.depend = "";
        this.date = new Date();
        this.duration = 0;
        this.history = [];
    }

    getId(){
        return this.taskid;
    }

    setDescription(description){
        this.description = description;
    }

    removeTask(){
        tasksBDD.removeTask(this.taskid);
        console.log("Tâche supprimée");
    }

    updateTaskStatus(statu){
        this.status = statu;
        console.log("Status mis à jour");
        this.history.push({status: statu, date: new Date()});
    }

    assignTaskToDeveloper(developerName){
        this.developer = developerName;
        console.log("Tâche assignée à un développeur");
    }

    setTaskDependency(dependentTaskId){
        this.depend = dependentTaskId;
        console.log("Dépendance ajoutée");
    }

    setTaskDeadline(deadline){
        this.date = deadline;
        console.log("Date ajoutée");
    }

    setTaskDurationEstimate(duration){
        this.duration = duration;
        console.log("Durée ajoutée");
    }

    linkTaskToIssue(issueId){
        this.issue = issueId;
        console.log("Tâche lié à un issue");
    }

    filterTasksByStatus(status){
        return TasksBDD.getAllTasks().filter(task => task.status === status);
    }

    filterTasksByDeveloper(developer){
        return TasksBDD.getAllTasks().filter(task => task.developer === developer);
    }

    addComment(comment){
        this.comments.push(comment);
        console.log("Commentaire ajouté");
    }

    getTaskHistory(taskId){
        return TasksBDD.getTaskById(taskId).history;
    }

    editTask(taskId, newTitle, newDescription){
        TasksBDD.getTaskById(taskId).taskname = newTitle;
        TasksBDD.getTaskById(taskId).taskdescription = newDescription;
        console.log("Tâche modifié");
    }
}


class Issues {
    constructor(id, description, status = "À faire") {
        this.id = id;
        this.description = description;
        this.status = status;
    }

    getId() {
        return this.id;
    }

    setStatus(newStatus) {
        this.status = newStatus;
        console.log(`Statut de l'issue mis à jour : ${newStatus}`);
    }

    setDescription(newDescription) {
        this.description = newDescription;
        console.log("Description de l'issue modifiée");
    }
}

class IssuesBDD {
    constructor() {
        this.issues = [];
    }

    addIssue(description) {
        if (description) {
            const issue = new Issues(Date.now(), description);
            this.issues.push(issue);
            console.log("Nouvelle issue ajoutée");
        }
    }

    listIssues() {
        console.log("Liste des issues :");
        this.issues.forEach(issue => {
            console.log(`ID: ${issue.id}, Description: ${issue.description}, Statut: ${issue.status}`);
        });
    }

    removeIssue(issueId) {
        const index = this.issues.findIndex(issue => issue.id === issueId);
        if (index !== -1) {
            this.issues.splice(index, 1);
            console.log("Issue supprimée");
        } else {
            console.log("Issue non trouvée pour suppression");
        }
    }

    filterIssuesByStatus(status) {
        return this.issues.filter(issue => issue.status === status);
    }

    getIssueById(issueId) {
        return this.issues.find(issue => issue.id === issueId);
    }

    associateIssueToRelease(issueId, release) {
        const issue = this.getIssueById(issueId);
        if (issue) {
            release.addIssue(issue);
            console.log("Issue associée à une release");
        } else {
            console.log("Issue non trouvée pour association");
        }
    }

    updateIssue(issueId, newDescription, newStatus) {
        const issue = this.getIssueById(issueId);
        if (issue) {
            issue.setDescription(newDescription);
            issue.setStatus(newStatus);
            console.log("Issue mise à jour");
        } else {
            console.log("Issue non trouvée pour mise à jour");
        }
    }
}


class Documentation {
    constructor(title, content, validityDate) {
        this.id = 0;
        this.title = title;
        this.content = content;
        this.validityDate = validityDate;
    }

    setDetails(newTitle, newContent, newValidityDate) {
        this.title = newTitle;
        this.content = newContent;
        this.validityDate = newValidityDate;
        console.log("Documentation mise à jour");
    }

    getId() {
        return this.id;
    }
}

class DocumentationBDD {
    constructor() {
        this.documentations = [];
    }

    addDocumentation(title, content, validityDate) {
        const doc = new Documentation(Date.now(), title, content, validityDate);
        this.documentations.push(doc);
        console.log("Nouvelle documentation ajoutée");
        return doc;
    }

    listDocumentations() {
        console.log("Liste des documentations :");
        this.documentations.forEach(doc => {
            console.log(`ID: ${doc.id}, Titre: ${doc.title}, Validité: ${doc.validityDate}`);
        });
    }

    removeDocumentation(docId) {
        const index = this.documentations.findIndex(doc => doc.id === docId);
        if (index !== -1) {
            this.documentations.splice(index, 1);
            console.log("Documentation supprimée");
        } else {
            console.log("Documentation non trouvée pour suppression");
        }
    }

    updateDocumentation(docId, newTitle, newContent, newValidityDate) {
        const doc = this.documentations.find(doc => doc.id === docId);
        if (doc) {
            doc.setDetails(newTitle, newContent, newValidityDate);
            console.log("Documentation mise à jour");
        } else {
            console.log("Documentation non trouvée");
        }
    }
}


class Release {
    constructor(id, title, description, releaseDate, status = "En cours") {
        this.id = id;
        this.title = title;
        this.description = description;
        this.releaseDate = releaseDate;
        this.status = status;
        this.issues = [];
    }

    getId() {
        return this.id;
    }

    addIssue(issue) {
        this.issues.push(issue);
        console.log("Issue ajoutée à la release");
    }

    setStatus(newStatus) {
        this.status = newStatus;
        console.log(`Statut de la release mis à jour : ${newStatus}`);
    }

    setDetails(newTitle, newDescription, newDate) {
        this.title = newTitle;
        this.description = newDescription;
        this.releaseDate = newDate;
        console.log("Détails de la release modifiés");
    }

    displayDetails() {
        console.log(`ID: ${this.id}, Titre: ${this.title}, Statut: ${this.status}`);
        console.log(`Date de sortie: ${this.releaseDate}, Description: ${this.description}`);
        console.log("Issues associées:");
        this.issues.forEach(issue => console.log(`- ${issue.description}`));
    }
}

class ReleasesBDD {
    constructor() {
        this.releases = [];
    }

    addRelease(title, description, releaseDate) {
        const release = new Release(Date.now(), title, description, releaseDate);
        this.releases.push(release);
        console.log("Nouvelle release ajoutée");
    }

    listReleases() {
        console.log("Liste des releases :");
        this.releases.forEach(release => {
            console.log(`ID: ${release.id}, Titre: ${release.title}, Statut: ${release.status}`);
        });
    }

    filterReleasesByStatus(status) {
        return this.releases.filter(release => release.status === status);
    }

    removeRelease(releaseId) {
        const index = this.releases.findIndex(release => release.id === releaseId);
        if (index !== -1) {
            this.releases.splice(index, 1);
            console.log("Release supprimée");
        } else {
            console.log("Release non trouvée pour suppression");
        }
    }

    getReleaseById(releaseId) {
        return this.releases.find(release => release.id === releaseId);
    }

    updateRelease(releaseId, newTitle, newDescription, newDate) {
        const release = this.getReleaseById(releaseId);
        if (release) {
            release.setDetails(newTitle, newDescription, newDate);
            console.log("Release mise à jour");
        } else {
            console.log("Release non trouvée pour mise à jour");
        }
    }
}


class GlobalBDD {
    constructor(){
        this.accountsBDD =  new AccountBDD();
        this.projectsBDD = new ProjectBDD();
        this.tasksBDD = tasksBDD;
        this.issuesBDD = issuesBDD;
        this.releasesBDD = releasesBDD;
        this.documentationBDD = documentationBDD;
    }
}

// base de données globale qui gère les comptes
class AccountBDD {
    constructor() {
        this.accounts = [];
        this.account_logged = null;
        this.addAccount("root","root");
    }


    addAccount(username, password) {
        if (this.accounts.some(account => account.username === username)) return false;
        const newAccount = new Account(username, password);
        this.accounts.push(newAccount);
        console.log(`Compte ajouté pour ${username}`);
        return true;
    }


    removeAccount(username) {
        const index = this.accounts.findIndex(account => account.username === username);
        if (index !== -1) {
            this.accounts.splice(index, 1);
            console.log(`Compte supprimé pour ${username}`);
        } else {
            console.log(`Aucun compte trouvé pour ${username}`);
        }
    }

    connectAccount(username, password){
        this.account_logged = this.accounts.find(account => account.username === username && account.password == password);
        if (this.account_logged != null) return true;
        return false;
    }

    logoutAccount(){
        this.account_logged = null;
    }


    findAccount(username) { // méthode à appeler pour savoir si un compte existe bien ou non
        console.log("compte existant : " + this.accounts.find(account => account.username === username));
        return this.accounts.find(account => account.username === username);
    }


    displayAllAccounts() {
        console.log('Liste des comptes :');
        this.accounts.forEach(account => account.displayInfo());
    }
}



class ProjectBDD {
    constructor() {
        this.projects = []; 
    }

    addProject(name, description, founder, mem_list) {
        const newProject = new Project(name, description, founder, mem_list);
        this.projects.push(newProject);
        console.log(`Projet "${name}" ajouté pour ${founder}`);
        return true;
    }

    checkProject(projectId){
        this.projects.forEach(project => {
            if (project.getId() === Number(projectId)) {
                if (project.projectIsLeft()) this.removeProject(projectId);
            }
        });
    }

    removeProject(projectId){
        const indexToRemove = this.projects.findIndex(project => project.getId() === Number(projectId));
        
        if (indexToRemove !== -1) {
            this.projects.splice(indexToRemove, 1); 
        }
    }

    addMemberToProject(projectId, newMember){
        this.projects.forEach(project => {
            if (project.getId() === Number(projectId)) {
                project.addMember(newMember);
            }
        });
    }
    
    getProjectById(projectId){
        this.projects.forEach(project => {
            if (project.getId() === Number(projectId)){
                return project;
            }
        });
    }    

    addTaskToProject(projectId, task) {
        const project = this.projects.find(proj => proj.id === projectId);
        if (project) {
            project.addTask(task);
            console.log(`Tâche ajoutée au projet "${project.projectname}"`);
        } else {
            console.log(`Projet avec l'ID ${projectId} non trouvé`);
        }
    }

    addIssueToProject(projectId, issue) {
        const project = this.projects.find(proj => proj.id === projectId);
        if (project) {
            project.addIssue(issue);
            console.log(`Issue ajoutée au projet "${project.projectname}"`);
        } else {
            console.log(`Projet avec l'ID ${projectId} non trouvé`);
        }
    }

    addDocumentationToProject(projectId, documentation) {
        const project = this.projects.find(proj => proj.id === projectId);
        if (project) {
            project.addDocumentation(documentation);
            console.log(`Documentation ajoutée au projet "${project.projectname}"`);
        } else {
            console.log(`Projet avec l'ID ${projectId} non trouvé`);
        }
    }

    displayAllProjects() {
        console.log('Liste des projets :');
        this.projects.forEach(project => project.displayMembers());
    }
}

class TasksBDD {
    constructor() {
        this.tasks = [];
    }

    addTask(title, description){
        if (title !== "" && description !== ""){
            const newTask = new Tasks(title, Date.now(), description, "À faire"); // Crée une tâche avec un ID unique
            this.tasks.push(newTask);
            console.log("Une nouvelle tâche a été ajoutée");
        }
    }

    getAllTasks(){
        return this.tasks;
    }

    getTaskById(id){
        return this.tasks.find(task => task.taskid === id);
    }

    removeTask(taskID){
        const index = this.tasks.findIndex(task => task.taskid === taskID);
        if (index !== -1) {
            this.tasks.splice(index, 1);
            console.log("Tâche supprimée");
        } else {
            console.log("Tâche non trouvée pour suppression");
        }
    }
}

const tasksBDD = new TasksBDD();
const issuesBDD = new IssuesBDD();
const releasesBDD = new ReleasesBDD();
const documentationBDD = new DocumentationBDD();


// Créer une instance de AccountBDD
const globalBDD = new GlobalBDD();

// Exporter l'instance
module.exports = globalBDD;
module.exports.Release = Release;
module.exports.Tasks = Tasks;
module.exports.Issues = Issues;
module.exports.Project = Project;
module.exports.Documentation = Documentation;