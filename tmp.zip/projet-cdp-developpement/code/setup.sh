#!/bin/bash

echo "Installation des dépendances..."
npm install express body-parser express-session --verbose

echo "Démarrage du serveur..."
node ./server.js

echo "Ouvrez maintenant https://localhost:3000/"