# Feature: Création d'une release

  ## Scenario: Créer une nouvelle release avec un titre, description, numéro de version et date de sortie prévue
    Given je suis sur la page des releases
    When je clique sur "Créer une release"
    And je saisis "v1.0" comme titre
    And je saisis "Première version de production" comme description
    And je saisis "1.0.0" comme numéro de version
    And je saisis "2024-12-01" comme date de sortie prévue
    Then une nouvelle release intitulée "v1.0" avec le numéro de version "1.0.0" est ajoutée à la liste des releases

# Feature: Vue en liste des releases

  ## Scenario: Afficher la liste des releases
    Given plusieurs releases existent
    When je suis sur la page des releases
    Then je vois une liste de toutes les releases
    And chaque release affiche son titre, numéro de version, et statut

# Feature: Suivi du statut d'une release

  ## Scenario: Marquer une release comme en cours
    Given une release est créée avec le statut "prévue"
    When je change le statut de la release à "en cours"
    Then le statut de la release est mis à jour en "en cours"
  
  ## Scenario: Marquer une release comme prête
    Given une release est en cours
    When je change le statut de la release à "prête"
    Then le statut de la release est mis à jour en "prête"

  ## Scenario: Marquer une release comme déployée
    Given une release est prête
    When je change le statut de la release à "déployée"
    Then le statut de la release est mis à jour en "déployée"

# Feature: Filtrage des releases par statut

  ## Scenario: Filtrer les releases par statut "en cours"
    Given plusieurs releases avec des statuts différents existent
    When je filtre les releases par statut "en cours"
    Then seules les releases avec le statut "en cours" sont affichées

# Feature: Consultation des détails d'une release

  ## Scenario: Voir les détails d'une release et les issues associées
    Given une release intitulée "v1.0" existe
    And des issues sont associées à cette release
    When je consulte les détails de la release "v1.0"
    Then je vois la description de la release, le numéro de version, la date de sortie, et la liste des issues associées

# Feature: Suppression d'une release

  ## Scenario: Supprimer une release de la liste
    Given une release existe dans la liste des releases
    When je supprime cette release
    Then la release n'apparaît plus dans la liste des releases

# Feature: Modification du contenu d'une release

  ## Scenario: Modifier la description et la date de sortie d'une release
    Given une release existe avec la description "Ancienne version"
    When je modifie la description de la release en "Version mise à jour"
    And je modifie la date de sortie à "2024-12-15"
    Then la description et la date de sortie de la release sont mises à jour
