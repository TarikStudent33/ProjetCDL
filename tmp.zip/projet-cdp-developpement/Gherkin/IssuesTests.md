# Feature: Création d'une issue

  ## Scenario: Créer une nouvelle issue avec une description
    Given je suis sur la page des issues
    When je clique sur "Créer une issue"
    And je saisis "Problème de connexion" comme description
    Then une nouvelle issue avec la description "Problème de connexion" est ajoutée à la liste des issues

# Feature: Identification unique d'une issue

  ## Scenario: Vérifier qu'une issue possède un identifiant unique
    Given une issue est créée avec la description "Erreur d'affichage"
    When je consulte les détails de cette issue
    Then je vois un numéro unique associé à cette issue

# Feature: Vue en liste des issues

  ## Scenario: Afficher la liste des issues
    Given plusieurs issues existent
    When je suis sur la page des issues
    Then je vois toutes les issues listées
    And chaque issue affiche son titre et sa description

# Feature: Suivi de l'avancement d'une issue

  ## Scenario: Marquer une issue comme en cours
    Given une issue existe avec le statut "non démarré"
    When je change le statut de l'issue à "en cours"
    Then le statut de l'issue est mis à jour en "en cours"
  
  ## Scenario: Marquer une issue comme terminée
    Given une issue est en cours
    When je change le statut de l'issue à "terminée"
    Then le statut de l'issue est mis à jour en "terminée"

# Feature: Association d'issues à une release

  ## Scenario: Associer une issue à une release spécifique
    Given une issue existe sans release associée
    When j'associe cette issue à la release "v1.0"
    Then la release "v1.0" est visible dans les détails de l'issue

# Feature: Suppression d'une issue

  ## Scenario: Supprimer une issue de la liste
    Given une issue existe dans la liste des issues
    When je supprime cette issue
    Then l'issue n'apparaît plus dans la liste des issues

# Feature: Filtrage des issues par statut

  ## Scenario: Filtrer les issues par statut "en cours"
    Given plusieurs issues avec des statuts différents existent
    When je filtre les issues par statut "en cours"
    Then seules les issues avec le statut "en cours" sont affichées

# Feature: Modification du contenu d'une issue

  ## Scenario: Modifier la description d'une issue
    Given une issue existe avec la description "Erreur d'affichage"
    When je modifie la description de l'issue en "Erreur de connexion"
    Then la description de l'issue est mise à jour en "Erreur de connexion"
