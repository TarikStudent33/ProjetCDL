# Feature: Création d'une documentation

  ## Scenario: Créer une nouvelle documentation avec titre, date de validité, et contenu
    Given je suis sur la page de gestion de la documentation
    When je clique sur "Créer une documentation"
    And je saisis "Guide utilisateur" comme titre
    And je saisis "2024-12-31" comme date de validité
    And je saisis "Instructions pour l'utilisation du produit" comme contenu
    Then une nouvelle documentation intitulée "Guide utilisateur" avec une date de validité "2024-12-31" est ajoutée à la liste

# Feature: Vue en liste des documentations

  ## Scenario: Afficher la liste des documentations
    Given plusieurs documentations existent
    When je suis sur la page de gestion de la documentation
    Then je vois une liste de toutes les documentations
    And chaque documentation affiche son titre, sa date de validité et un extrait de contenu

# Feature: Association de documentation à une release

  ## Scenario: Associer une documentation à une release spécifique
    Given une documentation existe sans release associée
    When j'associe cette documentation à la release "v1.0"
    Then la release "v1.0" est visible dans les détails de la documentation

# Feature: Suppression d'une documentation

  ## Scenario: Supprimer une documentation de la liste
    Given une documentation existe dans la liste des documentations
    When je supprime cette documentation
    Then la documentation n'apparaît plus dans la liste des documentations

# Feature: Modification du contenu d'une documentation

  ## Scenario: Modifier le contenu d'une documentation existante
    Given une documentation existe avec le contenu "Guide d'installation"
    When je modifie le contenu de la documentation en "Guide d'installation et configuration"
    Then le contenu de la documentation est mis à jour en "Guide d'installation et configuration"
