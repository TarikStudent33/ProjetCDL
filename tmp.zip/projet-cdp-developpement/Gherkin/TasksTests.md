# Feature: Création de tâche

  ## Scenario: Création d'une tâche avec un titre et une description
    Given je suis sur la page de création de tâche
    When je saisis "Titre de la tâche" dans le champ titre
    And je saisis "Description de la tâche" dans le champ description
    And je clique sur "Créer la tâche"
    Then une nouvelle tâche est créée avec le titre "Titre de la tâche" et la description "Description de la tâche"
    And la tâche est visible dans ma liste de tâches

# Feature: Affichage des tâches

  ## Scenario: Afficher toutes les tâches de l'utilisateur
    Given j'ai plusieurs tâches dans mon compte
    When je vais sur la page de mes tâches
    Then je vois une liste contenant toutes mes tâches
    And chaque tâche affiche au moins son titre, sa description et son statut

# Feature: Modification du statut de la tâche

  ## Scenario: Changer le statut d'une tâche
    Given une tâche existe avec le statut "À faire"
    When je change le statut de la tâche à "En cours de dev"
    Then le statut de la tâche est mis à jour à "En cours de dev"

# Feature: Suppression de tâche

  ## Scenario: Supprimer une tâche existante
    Given une tâche existe dans ma liste de tâches
    When je clique sur "Supprimer" pour cette tâche
    Then la tâche est supprimée de ma liste
    And je ne vois plus la tâche dans ma liste de tâches

# Feature: Affectation de tâche

  ## Scenario: Assigner une tâche à un développeur spécifique
    Given une tâche existe sans développeur assigné
    When j'assigne la tâche au développeur "Jean Dupont"
    Then la tâche est assignée au développeur "Jean Dupont"
    And je vois le nom "Jean Dupont" dans les détails de la tâche

# Feature: Filtrer les tâches par statut

  ## Scenario: Filtrer les tâches avec le statut "En cours de dev"
    Given plusieurs tâches avec différents statuts existent
    When je filtre les tâches par le statut "En cours de dev"
    Then je vois uniquement les tâches ayant le statut "En cours de dev" dans la liste

# Feature: Lier une tâche à une autre

  ## Scenario: Lier une tâche à une autre pour gérer les dépendances
    Given je suis sur la page de gestion des tâches
    And une tâche "Tâche A" existe
    And une tâche "Tâche B" existe
    When je sélectionne "Lier une tâche" pour "Tâche A"
    And je choisis "Tâche B" comme tâche liée
    Then "Tâche A" est liée à "Tâche B"
    And la relation de dépendance est visible dans les détails de la "Tâche A"

# Feature: Affecter une date de fin à une tâche

  ## Scenario: Définir une date de fin pour une tâche
    Given je suis sur la page de gestion des tâches
    And une tâche "Tâche A" existe
    When je sélectionne "Modifier la date de fin" pour "Tâche A"
    And je choisis la date "2024-11-30"
    Then la date de fin de "Tâche A" est définie au "2024-11-30"
    And cette date est visible dans les détails de la tâche

# Feature: Estimer la durée d'une tâche

  ## Scenario: Définir une estimation de la durée pour une tâche
    Given je suis sur la page de gestion des tâches
    And une tâche "Tâche A" existe
    When je saisis "4 heures" comme estimation de durée pour "Tâche A"
    Then l'estimation de durée de "Tâche A" est définie sur "4 heures"
    And cette estimation est visible dans les détails de la tâche

# Feature: Ajouter des commentaires à une tâche

  ## Scenario: Ajouter un commentaire à une tâche pour noter des détails
    Given je suis sur la page de gestion des tâches
    And une tâche "Tâche A" existe
    When je sélectionne "Ajouter un commentaire" pour "Tâche A"
    And je saisis "Vérifier l'intégration API"
    Then le commentaire "Vérifier l'intégration API" est ajouté à la "Tâche A"
    And il est visible dans la section des commentaires de la tâche

# Feature: Accéder à l'historique d'une tâche

  ## Scenario: Afficher l'historique des changements de statut d'une tâche
    Given je suis sur la page de gestion des tâches
    And une tâche "Tâche A" existe avec un historique de statut
    When je sélectionne "Afficher l'historique" pour "Tâche A"
    Then je vois les changements de statut passés de "Tâche A" dans l'historique
    And chaque changement indique le statut, la date et l'utilisateur responsable

# Feature: Modifier le contenu d'une tâche

  ## Scenario: Modifier le titre et la description d'une tâche
    Given je suis sur la page de gestion des tâches
    And une tâche "Tâche A" existe
    When je sélectionne "Modifier la tâche" pour "Tâche A"
    And je change le titre en "Nouvelle Tâche A"
    And je change la description en "Description mise à jour"
    Then le titre de la tâche est "Nouvelle Tâche A"
    And la description de la tâche est "Description mise à jour"

