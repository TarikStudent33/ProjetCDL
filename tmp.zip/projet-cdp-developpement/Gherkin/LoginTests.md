# Feature: Création de compte

  ## Scenario: Création d'un compte avec des informations valides
    Given je suis sur la page d'inscription
    When je saisis "Jean Dupont" dans le champ nom
    And je saisis "jean.dupont@example.com" dans le champ e-mail
    And je saisis "MotDePasse123" dans le champ mot de passe
    And je saisis "MotDePasse123" dans le champ confirmation du mot de passe
    And je clique sur "Créer mon compte"
    Then mon compte est créé avec succès
    And je suis redirigé vers la page de connexion

  ## Scenario: Création de compte avec un e-mail déjà utilisé
    Given je suis sur la page d'inscription
    When je saisis "Jean Dupont" dans le champ nom
    And je saisis "jean.dupont@example.com" (qui est déjà utilisé) dans le champ e-mail
    And je saisis "MotDePasse123" dans le champ mot de passe
    And je saisis "MotDePasse123" dans le champ confirmation du mot de passe
    And je clique sur "Créer mon compte"
    Then un message d'erreur "Cet e-mail est déjà utilisé" s'affiche


# Feature: Connexion

  ## Scenario: Connexion avec des informations valides
    Given je suis sur la page de connexion
    When je saisis "jean.dupont@example.com" dans le champ e-mail
    And je saisis "MotDePasse123" dans le champ mot de passe
    And je clique sur "Se connecter"
    Then je suis redirigé vers la page d'accueil des projets

  ## Scenario: Connexion avec un mot de passe incorrect
    Given je suis sur la page de connexion
    When je saisis "jean.dupont@example.com" dans le champ e-mail
    And je saisis "MotDePasseInvalide" dans le champ mot de passe
    And je clique sur "Se connecter"
    Then un message d'erreur "Mot de passe incorrect" s'affiche

# Feature: Déconnexion

  ## Scenario: Déconnexion réussie
    Given je suis connecté et sur la page d'accueil des projets
    When je clique sur le bouton "Se déconnecter"
    Then je suis redirigé vers la page de connexion
    And je ne peux plus accéder aux fonctionnalités réservées aux utilisateurs connectés
