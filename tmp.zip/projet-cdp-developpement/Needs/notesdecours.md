# Projet 

## Réaliser un outil pour gérer la production logicielle 
    
Gestions des issues 
Taches 
Releases
Test
Documentation
Sans inclure la gestion du code

Produire une application web 

Un channel Slack pour chaque équipe

Deux dépôts Git : 
Developpement
Release

Mise en abîme: 

Backlog (README.md)
Sprints (SprintX.md) -> release
Taches (TaskX.md) -> release
Release  (Release.md) -> release
Documentation (.md) -> release

Plusieurs sprints 

0: jusqu’au 1er novembre 
1: 4 nov -> 15 nov 
2: 18 nov -> 29 nov
3: 29 nov -> 13 dec 

Soutenance : 16 décembre (40% de la note finale) 
Radar (Questionnaire) 60% de la note finale 


Deux intervenant pendant le cours.