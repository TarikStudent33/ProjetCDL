# Liens

## Git

- git dev : https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-developpement

- git rel : https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-release

- besoins : https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-developpement/-/blob/main/Besoins.md

- issues : https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-developpement/-/blob/main/Issues.md

- tasks : https://gitlab.emi.u-bordeaux.fr/taitsaid/projet-cdp-developpement/-/blob/main/Tasks.md

## Organisation

- trello : 

## Communication

- slack(discord) : https://app.slack.com/

## Outils annexes

- outil pour maquettage (Figma) : https://www.figma.com/fr-fr/wireframe-tool/?utm_source=google&utm_medium=cpc&utm_campaign=21049479581&utm_term=wireframe%20en%20ligne&utm_content=692090160180&utm_adgroup=157943776526&gad_source=1&gclid=EAIaIQobChMIm-LR7PWeiQMVH_F5BB3vHxupEAAYASAAEgJYKvD_BwE



